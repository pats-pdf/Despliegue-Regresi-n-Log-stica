from pathlib import Path

import numpy as np
import pandas as pd

from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.model_selection import GroupShuffleSplit, train_test_split
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
    mean_absolute_error,
    mean_squared_error,
)


BASE = Path(__file__).resolve().parent

METODOS = [
    "Sin ajuste",
    "Reponderación",
    "Oversampling",
]


# LOCALIZACIÓN DE ARCHIVOS

def archivo(patron):
    for carpeta in [BASE, BASE / "data"]:
        rutas = sorted(carpeta.glob(patron))

        if len(rutas) > 1:
            raise ValueError(
                f"Conserva una sola versión de {patron}: "
                + ", ".join(p.name for p in rutas)
            )

        if rutas:
            return rutas[0]

    raise FileNotFoundError(
        f"Falta {patron} en la carpeta de app.py."
    )


# TRATAMIENTO DE ATÍPICOS

class IQR(BaseEstimator, TransformerMixin):
    def fit(self, X, y=None):
        a, b = np.percentile(X, [25, 75], axis=0)

        self.lo = np.where(
            b > a,
            a - 1.5 * (b - a),
            -np.inf,
        )

        self.hi = np.where(
            b > a,
            b + 1.5 * (b - a),
            np.inf,
        )

        return self

    def transform(self, X):
        return np.clip(X, self.lo, self.hi)

    def get_feature_names_out(self, input_features=None):
        return np.asarray(input_features, dtype=object)


def preparar(X):
    numericas = X.select_dtypes(
        include="number"
    ).columns.tolist()

    categoricas = [
        c for c in X
        if c not in numericas
    ]

    partes = []

    if numericas:
        partes.append((
            "num",
            Pipeline([
                (
                    "nulos",
                    SimpleImputer(
                        strategy="median",
                        keep_empty_features=True,
                    ),
                ),
                ("iqr", IQR()),
                ("escala", StandardScaler()),
            ]),
            numericas,
        ))

    if categoricas:
        partes.append((
            "cat",
            Pipeline([
                (
                    "nulos",
                    SimpleImputer(
                        strategy="constant",
                        fill_value="SIN REGISTRO",
                    ),
                ),
                (
                    "binarias",
                    OneHotEncoder(
                        handle_unknown="ignore",
                        sparse_output=False,
                    ),
                ),
            ]),
            categoricas,
        ))

    return ColumnTransformer(partes)


# MARKETING: REPORTE ORIGINAL Y TABLA MENSUAL

def reporte_marketing():
    return pd.read_csv(
        archivo("*Marketing*.csv"),
        header=None,
    )


def mensual():
    reporte = reporte_marketing()

    meses = dict(zip(
        [
            "enero", "febrero", "marzo", "abril",
            "mayo", "junio", "julio", "agosto",
            "septiembre", "octubre", "noviembre", "diciembre",
        ],
        range(1, 13),
    ))

    fechas = []

    for texto in reporte.iloc[139, 1:30]:
        mes, anio = str(texto).strip().lower().split(",")

        fechas.append(
            pd.Timestamp(
                2000 + int(anio),
                meses[mes.strip()],
                1,
            )
        )

    datos = pd.DataFrame({"Fecha": fechas})

    filas = {
        "Leads Plaza": 142,
        "Leads Digitales": 150,
        "Leads Piso": 158,
        "Ventas": 4,
    }

    for columna, fila in filas.items():
        valores = (
            reporte.iloc[fila, 1:30]
            .astype(str)
            .str.replace(",", "", regex=False)
        )

        datos[columna] = pd.to_numeric(
            valores,
            errors="coerce",
        ).to_numpy()

    return (
        datos.dropna(subset=["Fecha", "Ventas"])
        .sort_values("Fecha")
        .reset_index(drop=True)
    )


# CARGA DE LAS CUATRO ÁREAS

def cargar(area):
    if area == "Marketing":
        reporte = reporte_marketing()
        tablas = []

        ubicaciones = [
            ("Angelópolis", 23, 82),
            ("Tlaxcala", 88, 118),
            ("Pachuca", 122, 136),
        ]

        for plaza, inicio, fin in ubicaciones:
            tabla = reporte.iloc[
                inicio:fin,
                [1, 2, 3, 4, 5, 6],
            ].copy()

            tabla.columns = [
                "Inicio",
                "Fin",
                "Días",
                "Modelo",
                "Color",
                "Leads",
            ]

            tabla["Plaza"] = plaza
            tablas.append(tabla)

        datos = pd.concat(tablas, ignore_index=True)
        originales = len(datos)

        for columna in ["Inicio", "Fin"]:
            datos[columna] = pd.to_datetime(
                datos[columna],
                format="%m/%d/%Y",
                errors="coerce",
            )

        for columna in ["Días", "Leads"]:
            datos[columna] = pd.to_numeric(
                datos[columna],
                errors="coerce",
            )

        datos = datos.dropna(subset=[
            "Inicio",
            "Fin",
            "Días",
            "Leads",
            "Modelo",
            "Color",
        ])

        datos = datos[
            (datos["Días"] > 0)
            & (datos["Leads"] >= 0)
            & (datos["Fin"] >= datos["Inicio"])
        ].copy()

        datos["Leads por día"] = (
            datos["Leads"] / datos["Días"]
        )

        datos["Mes inicio"] = (
            datos["Inicio"].dt.month.astype(float)
        )

        datos["Periodo"] = (
            datos["Inicio"].dt.to_period("M").astype(str)
        )

        objetivos = ["Captación ≥ 4 leads por día"]

        variables = [
            "Plaza",
            "Modelo",
            "Color",
            "Días",
            "Mes inicio",
        ]

        nota = (
            "Una fila es una exhibición. Corte analítico común: "
            "4 leads/día; no es una meta oficial. Se usa la "
            "duración reportada. Las plazas tienen diferentes "
            "niveles de captación; más filas no garantiza "
            "mejor predicción."
        )

    elif area == "Funnel":
        datos = pd.read_csv(
            archivo("Funnel_limpia*.csv")
        )

        datos.columns = datos.columns.str.strip()
        originales = len(datos)

        numericas = [
            "anio",
            "mes_num",
            "ventas",
            "leads_generados",
            "cita_efectiva",
            "prueba_de_manejo",
        ]

        for columna in numericas:
            datos[columna] = pd.to_numeric(
                datos[columna],
                errors="coerce",
            )

        datos = datos.dropna(
            subset=["anio", "mes_num", "ventas"]
        )

        datos = datos[
            (datos["ventas"] >= 0)
            & datos["mes_num"].isin(range(1, 13))
        ].copy()

        datos["Periodo"] = (
            datos["anio"].astype(int).astype(str)
            + "-"
            + datos["mes_num"].astype(int).astype(str)
        )

        objetivos = ["Canal-mes con ≥ 5 ventas"]

        variables = [
            "canal",
            "leads_generados",
            "cita_efectiva",
            "prueba_de_manejo",
        ]

        nota = (
            "Una fila es un canal-mes. Recupera las entradas "
            "de la calculadora original. Citas y pruebas son "
            "indicadores del mismo periodo: es una simulación "
            "con actividad comercial conocida, no un pronóstico "
            "al inicio del mes. Cerrador y formalizado "
            "se excluyen."
        )

    elif area == "Leads":
        datos = pd.read_csv(
            archivo("base leads*.csv")
        )

        datos.columns = datos.columns.str.strip()
        originales = len(datos)

        for columna in datos.columns:
            datos[columna] = pd.to_numeric(
                datos[columna],
                errors="coerce",
            )

        datos = datos.dropna(subset=[
            "Año",
            "Mes",
            "Total",
            "Efectivos",
            "Ventas",
        ])

        datos = datos[
            (datos["Total"] > 0)
            & (datos["Efectivos"] > 0)
            & (datos["Ventas"] >= 0)
            & (datos["Ventas"] <= datos["Efectivos"])
        ].copy()

        datos["Conversión (%)"] = (
            100 * datos["Ventas"] / datos["Efectivos"]
        )

        objetivos = ["Conversión mensual ≥ 4%"]

        variables = [
            "Total",
            "Efectivos",
            "Ilocalizable",
            "No Contesta",
            "D. Incorrectos",
            "Duplicados",
        ]

        nota = (
            "Una fila es un mes. Conversión = Ventas/Efectivos. "
            "Ventas, Conversion y Abiertos se excluyen como "
            "predictores. La clasificación no es la compra "
            "individual de un cliente."
        )

    else:
        datos = pd.read_csv(
            archivo("Plazas_sin_nulos*.csv")
        )

        datos.columns = datos.columns.str.strip()
        originales = len(datos)

        fecha = pd.to_datetime(
            datos["Fecha Origen"],
            errors="coerce",
        )

        datos["Hora"] = fecha.dt.hour.astype(float)

        datos["Día semana"] = (
            fecha.dt.dayofweek.astype(float)
        )

        objetivos = [
            "Seguimiento",
            "Cita efetiva",
            "PDM",
            "SDC",
        ]

        for columna in objetivos:
            valores = pd.to_numeric(
                datos[columna],
                errors="coerce",
            )

            datos[columna] = valores.where(
                valores.isin([0, 1])
            )

        variables = [
            "Producto",
            "Origen",
            "Hora",
            "Día semana",
        ]

        nota = (
            "Una fila es un lead. Se usan solo características "
            "del origen, sin etapas posteriores, nombres, "
            "teléfono ni comentarios. La limpieza anterior "
            "del archivo sin nulos no puede reconstruirse "
            "sin la fuente bruta."
        )

    for columna in variables:
        if pd.api.types.is_numeric_dtype(datos[columna]):
            datos.loc[
                datos[columna] < 0,
                columna,
            ] = np.nan

        else:
            serie = (
                datos[columna]
                .astype("string")
                .str.upper()
                .str.strip()
                .str.replace(r"\s+", " ", regex=True)
            )

            serie = serie.replace({
                "": pd.NA,
                "SIN REGISTRO": pd.NA,
            })

            datos[columna] = (
                serie.astype(object)
                .where(serie.notna(), np.nan)
            )

    return (
        datos.reset_index(drop=True),
        variables,
        objetivos,
        nota,
        originales,
    )


# OBJETIVOS DICOTÓMICOS

def objetivo(datos, area, nombre):
    if area == "Marketing":
        return (
            datos["Leads por día"] >= 4
        ).astype(int)

    if area == "Funnel":
        return (
            datos["ventas"] >= 5
        ).astype(int)

    if area == "Leads":
        return (
            datos["Conversión (%)"] >= 4
        ).astype(int)

    return datos[nombre]


# SEPARACIÓN DE ENTRENAMIENTO Y PRUEBA

def dividir(datos, y):
    indices = np.arange(len(datos))

    if "Periodo" in datos:
        separador = GroupShuffleSplit(
            n_splits=1,
            test_size=0.25,
            random_state=42,
        )

        return next(
            separador.split(
                datos,
                y,
                datos["Periodo"],
            )
        )

    return train_test_split(
        indices,
        test_size=0.25,
        random_state=42,
        stratify=y,
    )


# REGRESIÓN LOGÍSTICA Y BALANCEO

def ajustar(X, y, metodo):
    preparador = preparar(X)

    transformada = preparador.fit_transform(X)

    clases = np.asarray(y, dtype=int)

    if metodo == "Oversampling":
        frecuencias = np.bincount(
            clases,
            minlength=2,
        )

        adicionales = np.random.default_rng(42).choice(
            np.flatnonzero(
                clases == np.argmin(frecuencias)
            ),
            int(
                frecuencias.max() - frecuencias.min()
            ),
            replace=True,
        )

        indices = np.r_[
            np.arange(len(clases)),
            adicionales,
        ]

        transformada = transformada[indices]
        clases = clases[indices]

    modelo = LogisticRegression(
        max_iter=3000,
        class_weight=(
            "balanced"
            if metodo == "Reponderación"
            else None
        ),
        random_state=42,
    )

    modelo.fit(transformada, clases)

    return Pipeline([
        ("pre", preparador),
        ("modelo", modelo),
    ])


def metricas(y, probabilidades, corte):
    predicciones = (
        probabilidades >= corte
    ).astype(int)

    vn, fp, fn, vp = confusion_matrix(
        y,
        predicciones,
        labels=[0, 1],
    ).ravel()

    return {
        "Exactitud": accuracy_score(
            y,
            predicciones,
        ),
        "Precisión": precision_score(
            y,
            predicciones,
            zero_division=0,
        ),
        "Sensibilidad": recall_score(
            y,
            predicciones,
            zero_division=0,
        ),
        "F1": f1_score(
            y,
            predicciones,
            zero_division=0,
        ),
        "AUC": (
            roc_auc_score(y, probabilidades)
            if pd.Series(y).nunique() == 2
            else np.nan
        ),
        "VN": int(vn),
        "FP": int(fp),
        "FN": int(fn),
        "VP": int(vp),
    }


def evaluar(area, nombre, corte=0.5):
    datos, variables, _, nota, originales = cargar(area)

    y = objetivo(datos, area, nombre)

    validos = y.notna()

    datos = datos.loc[
        validos
    ].reset_index(drop=True)

    y = (
        y.loc[validos]
        .astype(int)
        .reset_index(drop=True)
    )

    if y.nunique() < 2 or y.value_counts().min() < 4:
        raise ValueError(
            "Se requieren al menos 4 casos de cada clase."
        )

    entrenamiento, prueba = dividir(datos, y)

    if y.iloc[entrenamiento].nunique() < 2:
        raise ValueError(
            "El entrenamiento no contiene ambas clases."
        )

    modelos = {}
    probabilidades = {}
    filas = []

    for metodo in METODOS:
        modelo = ajustar(
            datos[variables].iloc[entrenamiento],
            y.iloc[entrenamiento],
            metodo,
        )

        probabilidad = modelo.predict_proba(
            datos[variables].iloc[prueba]
        )[:, 1]

        modelos[metodo] = modelo
        probabilidades[metodo] = probabilidad

        filas.append({
            "Método": metodo,
            **metricas(
                y.iloc[prueba],
                probabilidad,
                corte,
            ),
        })

    return {
        "d": datos,
        "xs": variables,
        "y": y,
        "tr": entrenamiento,
        "te": prueba,
        "modelos": modelos,
        "probs": probabilidades,
        "tabla": pd.DataFrame(filas),
        "nota": nota,
        "original": originales,
    }


# ESTIMACIÓN NUMÉRICA DE VENTAS
# Complementa la clasificación logística.

def ventas_modelo(tipo="Funnel"):
    if tipo == "Marketing mensual":
        datos = mensual()

        variables = [
            "Leads Plaza",
            "Leads Digitales",
            "Leads Piso",
        ]

        entrenamiento = np.arange(
            len(datos) - 6
        )

        prueba = np.arange(
            len(datos) - 6,
            len(datos),
        )

        objetivo_ventas = "Ventas"

    else:
        datos, variables, _, _, _ = cargar("Funnel")

        objetivo_ventas = "ventas"

        entrenamiento, prueba = dividir(
            datos,
            datos[objetivo_ventas],
        )

    modelo = Pipeline([
        ("pre", preparar(datos[variables])),
        ("modelo", Ridge(alpha=10.0)),
    ])

    modelo.fit(
        datos[variables].iloc[entrenamiento],
        datos[objetivo_ventas].iloc[entrenamiento],
    )

    predicciones = np.maximum(
        0,
        modelo.predict(
            datos[variables].iloc[prueba]
        ),
    )

    referencia = np.repeat(
        datos[objetivo_ventas].iloc[
            entrenamiento
        ].mean(),
        len(prueba),
    )

    reales = datos[objetivo_ventas].iloc[prueba]

    resumen = pd.DataFrame([
        {
            "Modelo": "Regresión Ridge",
            "MAE": mean_absolute_error(
                reales,
                predicciones,
            ),
            "RMSE": np.sqrt(
                mean_squared_error(
                    reales,
                    predicciones,
                )
            ),
        },
        {
            "Modelo": "Media de entrenamiento",
            "MAE": mean_absolute_error(
                reales,
                referencia,
            ),
            "RMSE": np.sqrt(
                mean_squared_error(
                    reales,
                    referencia,
                )
            ),
        },
    ])

    return (
        modelo,
        datos,
        variables,
        entrenamiento,
        prueba,
        resumen,
    )


# COMPARACIÓN CON RANKING

def ranking(ventas, periodo="Acum 2025"):
    datos = pd.read_csv(
        archivo("ventas_a_anual*.csv")
    )

    datos.columns = datos.columns.str.strip()

    referencia = pd.to_numeric(
        datos[periodo],
        errors="coerce",
    ).dropna()

    referencia = referencia[
        referencia >= 0
    ]

    posicion = int(
        (referencia > ventas).sum()
    ) + 1

    empates = int(
        (referencia == ventas).sum()
    )

    return posicion, empates, len(referencia)