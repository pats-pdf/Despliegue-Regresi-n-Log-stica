

import streamlit as st
import pandas as pd
import joblib
from pathlib import Path

# ==========================================================
# 1. CONFIGURACIÓN GENERAL
# ==========================================================

st.set_page_config(
    page_title="GAC | Funnel Intelligence",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="collapsed"
)

BASE_DIR = Path(__file__).resolve().parent

RUTA_MODELO = BASE_DIR / "modelo_logistico_funnel.joblib"
RUTA_CONFIG = BASE_DIR / "configuracion_funnel.joblib"
RUTA_LOGO = BASE_DIR / "logo_gac.png"

# ==========================================================
# 2. DISEÑO VISUAL GAC
# ==========================================================

st.markdown("""
<style>
    .stApp {
        background-color: #0B0D12;
        color: #F8FAFC;
    }

    .block-container {
        max-width: 1250px;
        padding-top: 2rem;
        padding-bottom: 3rem;
    }

    header[data-testid="stHeader"] {
        background: transparent;
    }

    h1, h2, h3 {
        color: #FFFFFF !important;
        letter-spacing: -0.5px;
    }

    p, label {
        color: #D1D5DB;
    }

    .header-title {
        color: #FFFFFF;
        font-size: 34px;
        font-weight: 800;
        line-height: 1.2;
    }

    .header-subtitle {
        color: #9CA3AF;
        font-size: 14px;
        margin-top: 7px;
    }

    .red-line {
        height: 3px;
        border-radius: 8px;
        background: linear-gradient(
            90deg,
            #C8102E,
            #F43F5E,
            transparent
        );
        margin: 22px 0 35px 0;
    }

    .section-label {
        color: #F43F5E;
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 1.5px;
        text-transform: uppercase;
        margin-bottom: 10px;
    }

    div[data-testid="stVerticalBlockBorderWrapper"] {
        border-color: #30343F !important;
        border-radius: 15px !important;
    }

    div[data-testid="stNumberInput"] input {
        background-color: #171B24;
        color: #FFFFFF;
        border-radius: 8px;
    }

    div.stButton > button[kind="primary"] {
        background: linear-gradient(
            110deg,
            #A90E29,
            #D4193D
        );
        border: none;
        color: white;
        font-weight: 700;
        border-radius: 10px;
        padding: 13px 24px;
    }

    div.stButton > button[kind="primary"]:hover {
        background: #EF244C;
        color: white;
        box-shadow: 0 4px 20px #C8102E55;
    }

    .result-card {
        background: linear-gradient(
            135deg,
            #35101D,
            #180D15
        );
        border: 1px solid #812039;
        border-radius: 17px;
        padding: 30px;
        margin-top: 12px;
        min-height: 220px;
    }

    .result-label {
        color: #F5C1CC;
        font-size: 15px;
        font-weight: 600;
    }

    .result-value {
        color: #FFFFFF;
        font-size: 60px;
        font-weight: 800;
        margin: 12px 0;
        letter-spacing: -2px;
    }

    .result-description {
        color: #D1A5B0;
        font-size: 13px;
        line-height: 1.7;
    }

    .info-card {
        background: #151922;
        border: 1px solid #303642;
        border-radius: 13px;
        padding: 22px;
        margin-top: 12px;
    }

    .info-title {
        color: #FFFFFF;
        font-size: 15px;
        font-weight: 700;
        margin-bottom: 10px;
    }

    .info-text {
        color: #AEB5C2;
        font-size: 13px;
        line-height: 1.8;
    }

    div[data-testid="stMetric"] {
        background: #151922;
        border: 1px solid #303642;
        border-radius: 12px;
        padding: 18px;
    }

    .footer {
        color: #777E8D;
        font-size: 12px;
        text-align: center;
        margin-top: 45px;
        padding-top: 20px;
        border-top: 1px solid #252A34;
    }

    @media (max-width: 768px) {
        .header-title {
            font-size: 25px;
        }

        .result-value {
            font-size: 46px;
        }
    }
</style>
""", unsafe_allow_html=True)

# ==========================================================
# 3. CARGAR MODELO
# ==========================================================

@st.cache_resource
def cargar_modelo():
    modelo = joblib.load(RUTA_MODELO)
    config = joblib.load(RUTA_CONFIG)
    return modelo, config


try:
    modelo, config = cargar_modelo()

except Exception as error:
    st.error(
        "No fue posible cargar el modelo. "
        "Verifica que los archivos .joblib estén "
        "en la misma carpeta que app.py."
    )
    st.exception(error)
    st.stop()


rangos = config["rangos"]
canales = config["canales"]

# ==========================================================
# 4. ENCABEZADO CON LOGO ORIGINAL
# ==========================================================

col_logo, col_titulo = st.columns(
    [1, 5],
    gap="medium",
    vertical_alignment="center"
)

with col_logo:
    if RUTA_LOGO.exists():
        st.image(
            str(RUTA_LOGO),
            width="stretch"
        )
    else:
        st.warning("No se encontró logo_gac.png")

with col_titulo:
    st.markdown(
        """
        <div class="header-title">
            Funnel Intelligence
        </div>
        <div class="header-subtitle">
            Simulador de probabilidad de ventas
            | Regresión logística
        </div>
        """,
        unsafe_allow_html=True
    )

st.markdown(
    '<div class="red-line"></div>',
    unsafe_allow_html=True
)

# ==========================================================
# 5. TÍTULO PRINCIPAL
# ==========================================================

st.markdown(
    '<div class="section-label">MODELO PREDICTIVO</div>',
    unsafe_allow_html=True
)

st.title("Calculadora de Probabilidad Comercial")

st.write(
    "Explora escenarios comerciales y estima la "
    "probabilidad de que un canal alcance al menos "
    "**5 ventas durante un mes**."
)

st.write("")

# ==========================================================
# 6. VARIABLES DEL ESCENARIO
# ==========================================================

st.subheader("Configuración del escenario")

st.caption(
    "Selecciona un canal comercial e introduce "
    "los indicadores mensuales que deseas evaluar."
)

with st.container(border=True):

    canal = st.selectbox(
        "Canal comercial",
        options=canales,
        index=0,
        help="Selecciona el canal que deseas analizar."
    )

    st.write("")

    col1, col2, col3 = st.columns(3, gap="large")

    with col1:
        leads = st.number_input(
            "Leads generados",
            min_value=0,
            max_value=10000,
            value=int(
                rangos["leads_generados"]["mediana"]
            ),
            step=1,
            help="Cantidad mensual de leads generados."
        )

    with col2:
        citas = st.number_input(
            "Citas efectivas",
            min_value=0,
            max_value=10000,
            value=int(
                rangos["cita_efectiva"]["mediana"]
            ),
            step=1,
            help="Cantidad mensual de citas efectivas."
        )

    with col3:
        pruebas = st.number_input(
            "Pruebas de manejo",
            min_value=0,
            max_value=10000,
            value=int(
                rangos["prueba_de_manejo"]["mediana"]
            ),
            step=1,
            help="Cantidad mensual de pruebas de manejo."
        )

    st.write("")

    calcular = st.button(
        "Calcular probabilidad estimada",
        type="primary",
        use_container_width=True
    )

# ==========================================================
# 7. VALIDACIÓN DEL ESCENARIO
# ==========================================================

def validar_escenario(leads, citas, pruebas, rangos):

    advertencias = []

    valores = {
        "leads_generados": leads,
        "cita_efectiva": citas,
        "prueba_de_manejo": pruebas
    }

    nombres = {
        "leads_generados": "Leads generados",
        "cita_efectiva": "Citas efectivas",
        "prueba_de_manejo": "Pruebas de manejo"
    }

    for variable, valor in valores.items():

        minimo = rangos[variable]["min"]
        maximo = rangos[variable]["max"]

        if valor < minimo or valor > maximo:
            advertencias.append(
                f"{nombres[variable]} está fuera del "
                f"rango histórico ({minimo}–{maximo})."
            )

    if citas > leads:
        advertencias.append(
            "Las citas efectivas superan los leads "
            "generados. Revisa los valores."
        )

    if pruebas > citas:
        advertencias.append(
            "Las pruebas de manejo superan las citas "
            "efectivas. Revisa si esto coincide "
            "con la definición de tus indicadores."
        )

    return advertencias

# ==========================================================
# 8. CÁLCULO DE LA PROBABILIDAD
# ==========================================================

if calcular:

    advertencias = validar_escenario(
        leads,
        citas,
        pruebas,
        rangos
    )

    entrada = pd.DataFrame([{
        "leads_generados": leads,
        "cita_efectiva": citas,
        "prueba_de_manejo": pruebas,
        "canal": canal
    }])

    try:

        # Identificar la clase positiva del modelo
        clases = list(modelo.classes_)
        indice_positivo = clases.index(1)

        # Calcular probabilidad
        probabilidad = float(
            modelo.predict_proba(entrada)[
                0, indice_positivo
            ]
        )

        porcentaje = probabilidad * 100

        # ==================================================
        # 9. RESULTADO PRINCIPAL
        # ==================================================

        st.write("")
        st.subheader("Resultado de la simulación")

        col_resultado, col_info = st.columns(
            [1.25, 1],
            gap="large"
        )

        with col_resultado:

            st.markdown(
                f"""
                <div class="result-card">
                    <div class="result-label">
                        Probabilidad estimada de alcanzar
                        al menos 5 ventas
                    </div>
                    <div class="result-value">
                        {porcentaje:.1f}%
                    </div>
                    <div class="result-description">
                        Modelo: Regresión logística
                    </div>
                </div>
                """,
                unsafe_allow_html=True
            )

            st.write("")

            st.progress(
                min(max(probabilidad, 0.0), 1.0)
            )

            st.caption(
                "Probabilidad estimada para el "
                "escenario mensual seleccionado."
            )

        with col_info:

            if advertencias:
                st.warning(
                    "El escenario presenta advertencias."
                )

                for aviso in advertencias:
                    st.write(f"• {aviso}")

            else:
                st.success(
                    "Los valores individuales están "
                    "dentro de los rangos históricos "
                    "y no presentan inconsistencias "
                    "en las validaciones básicas."
                )

            st.markdown(
                """
                <div class="info-card">
                    <div class="info-title">
                        ¿Cómo interpretar el resultado?
                    </div>
                    <div class="info-text">
                        La probabilidad representa la
                        estimación del modelo para alcanzar
                        cinco o más ventas durante el mes,
                        considerando el canal y los
                        indicadores seleccionados.
                        <br><br>
                        No representa una garantía de
                        ventas ni demuestra relaciones
                        causales entre las variables.
                    </div>
                </div>
                """,
                unsafe_allow_html=True
            )

        # ==================================================
        # 10. RESUMEN DEL ESCENARIO
        # ==================================================

        st.write("")
        st.subheader("Resumen del escenario")

        r1, r2, r3, r4 = st.columns(4)

        r1.metric("Canal comercial", str(canal))
        r2.metric("Leads generados", f"{leads:,}")
        r3.metric("Citas efectivas", f"{citas:,}")
        r4.metric("Pruebas de manejo", f"{pruebas:,}")

    except Exception as error:

        st.error(
            "No se pudo calcular la probabilidad. "
            "Verifica la compatibilidad del modelo."
        )

        st.exception(error)

# ==========================================================
# 11. METODOLOGÍA Y LIMITACIONES
# ==========================================================

st.write("")
st.markdown("---")

with st.expander(
    "Metodología y limitaciones del modelo"
):

    st.markdown("""
    ### Modelo utilizado

    **Algoritmo:** Regresión logística.

    **Variable objetivo:** Alcanzar al menos
    cinco ventas mensuales.

    **Variables predictoras:**

    - Canal comercial.
    - Leads generados.
    - Citas efectivas.
    - Pruebas de manejo.

    ### Evaluación temporal histórica

    | Métrica | Resultado |
    |---|---:|
    | Accuracy | 89.83% |
    | ROC-AUC | 0.9838 |
    | Brier Score | 0.0593 |
    | Observaciones evaluadas | 59 |

    ### Limitaciones

    El modelo se evaluó utilizando información
    mensual completa.

    No ha sido validado para predecir resultados
    utilizando información parcial del mes.

    Los escenarios fuera de los rangos históricos
    pueden generar estimaciones menos confiables.

    Las probabilidades son estimaciones
    estadísticas, no garantías comerciales.
    """)

# ==========================================================
# 12. PIE DE PÁGINA
# ==========================================================

st.markdown(
    """
    <div class="footer">
        GAC | Funnel Intelligence
        <br>
        Analítica comercial y Machine Learning
    </div>
    """,
    unsafe_allow_html=True
)
