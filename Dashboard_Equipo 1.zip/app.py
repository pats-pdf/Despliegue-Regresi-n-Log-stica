from pathlib import Path

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from sklearn.metrics import roc_curve

from modelos import (
    cargar,
    evaluar,
    ventas_modelo,
    ranking,
    METODOS,
)


# CONFIGURACIÓN GENERAL

st.set_page_config(
    page_title="GAC | Inteligencia Comercial",
    page_icon="🚗",
    layout="wide",
)

CARPETA = Path(__file__).resolve().parent

st.markdown(
    """
    <style>
    .block-container {
        max-width: 1350px;
        padding-top: 2rem;
    }

    h1 {
        letter-spacing: -1px;
    }

    [data-testid="stMetric"] {
        background: #151B26;
        border: 1px solid #303848;
        border-radius: 14px;
        padding: 17px;
    }

    .linea-gac {
        height: 3px;
        background: linear-gradient(
            90deg, #E32636, transparent
        );
        margin: 15px 0 25px;
    }
    </style>
    """,
    unsafe_allow_html=True,
)


# FUNCIONES

@st.cache_data
def clasificar(area, nombre, corte):
    return evaluar(area, nombre, corte)


@st.cache_resource
def regresion(tipo):
    return ventas_modelo(tipo)


def grafica(figura):
    figura.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
    )

    st.plotly_chart(
        figura,
        use_container_width=True,
    )


def convertir_csv(datos):
    return datos.to_csv(
        index=False
    ).encode("utf-8-sig")


def formulario(X, clave):
    valores = {}
    columnas = st.columns(2)

    etiquetas = {
        "canal": "Canal comercial",
        "leads_generados": "Leads generados",
        "cita_efectiva": "Citas efectivas",
        "prueba_de_manejo": "Pruebas de manejo",
    }

    for i, variable in enumerate(X.columns):
        with columnas[i % 2]:
            serie = X[variable]

            etiqueta = etiquetas.get(
                variable,
                variable,
            )

            if pd.api.types.is_numeric_dtype(serie):
                minimo = (
                    1.0
                    if variable in ["Días", "Mes inicio"]
                    else 0.0
                )

                maximo = {
                    "Hora": 23.0,
                    "Día semana": 6.0,
                    "Mes inicio": 12.0,
                }.get(variable)

                inicial = (
                    float(serie.median())
                    if serie.notna().any()
                    else minimo
                )

                valores[variable] = st.number_input(
                    etiqueta,
                    min_value=minimo,
                    max_value=maximo,
                    value=max(inicial, minimo),
                    step=1.0,
                    key=f"{clave}_{variable}",
                )

                if (
                    serie.notna().any()
                    and not (
                        serie.min()
                        <= valores[variable]
                        <= serie.max()
                    )
                ):
                    st.caption(
                        "Valor fuera del rango histórico observado."
                    )

            else:
                opciones = sorted(
                    serie.dropna().unique().tolist()
                ) or ["SIN REGISTRO"]

                valores[variable] = st.selectbox(
                    etiqueta,
                    opciones,
                    key=f"{clave}_{variable}",
                )

    if "Día semana" in X.columns:
        st.caption(
            "Día de la semana: 0=Lunes, 1=Martes, "
            "2=Miércoles, 3=Jueves, 4=Viernes, "
            "5=Sábado, 6=Domingo."
        )

    if "Mes inicio" in X.columns:
        st.caption(
            "Mes de inicio: 1=Enero, 2=Febrero, "
            "… 12=Diciembre."
        )

    return pd.DataFrame([valores])


def mostrar_probabilidad(
    resultado,
    entrada,
    metodo,
    corte,
):
    if "Efectivos" in entrada:
        if (
            entrada["Efectivos"].iloc[0]
            > entrada["Total"].iloc[0]
        ):
            st.error(
                "Los leads efectivos no pueden "
                "superar el total."
            )
            return None

    if "cita_efectiva" in entrada:
        citas = entrada["cita_efectiva"].iloc[0]
        leads = entrada["leads_generados"].iloc[0]
        pruebas = entrada["prueba_de_manejo"].iloc[0]

        if citas > leads or pruebas > citas:
            st.warning(
                "Una etapa supera a la anterior. "
                "Revisa las cantidades y si los indicadores "
                "corresponden a la misma cohorte."
            )

    probabilidad = float(
        resultado["modelos"][metodo].predict_proba(
            entrada
        )[0, 1]
    )

    st.metric(
        "Puntuación de probabilidad",
        f"{probabilidad:.1%}",
    )

    st.progress(probabilidad)

    st.write(
        "**Clasificación: Sí**"
        if probabilidad >= corte
        else "**Clasificación: No**"
    )

    return probabilidad


def aviso_probabilidad():
    st.caption(
        "Con reponderación u oversampling, las probabilidades "
        "no están calibradas a la frecuencia real. "
        "Son puntuaciones del modelo, no garantías "
        "ni efectos causales."
    )


DESCRIPCIONES = {
    "Marketing": (
        "Analiza si una exhibición alcanza al menos "
        "4 leads por día según la plaza, modelo, color, "
        "duración y mes de inicio. Incluye una herramienta "
        "adicional para estimar ventas mensuales."
    ),
    "Funnel": (
        "Selecciona el canal e ingresa sus leads, citas "
        "efectivas y pruebas de manejo. Obtendrás la "
        "clasificación de al menos 5 ventas y una "
        "estimación numérica de ventas del canal-mes."
    ),
    "Leads": (
        "Ingresa el volumen mensual de leads y sus "
        "categorías de calidad para clasificar si "
        "la conversión sobre efectivos alcanza al menos 4%."
    ),
    "Plazas": (
        "Describe un lead mediante producto, origen, "
        "hora y día de la semana. Elige si quieres "
        "clasificar seguimiento, cita efectiva, prueba "
        "de manejo o solicitud de crédito."
    ),
}


# ENCABEZADO Y MENÚ

st.title("GAC | Inteligencia Comercial")

st.caption(
    "Análisis comercial, calculadoras y comparación de escenarios"
)

st.markdown(
    '<div class="linea-gac"></div>',
    unsafe_allow_html=True,
)

logo = CARPETA / "logo_gac.png"

if logo.exists():
    st.sidebar.image(
        str(logo),
        width=160,
    )

st.sidebar.markdown("### Herramientas de análisis")

area = st.sidebar.selectbox(
    "Área",
    [
        "Marketing",
        "Funnel",
        "Leads",
        "Plazas",
        "Ranking",
    ],
)

st.sidebar.caption(
    "El área seleccionada controla Calculadoras específicas, "
    "Escenarios A/B y Evaluación y datos."
)


# CARGA DE MODELO SELECCIONADO

resultado = None
error_area = None
datos = None
variables = []
nombre = None
metodo = None
corte = 0.5

if area != "Ranking":
    try:
        (
            datos,
            variables,
            objetivos,
            nota,
            originales,
        ) = cargar(area)

        nombre = st.sidebar.selectbox(
            "Resultado a clasificar",
            objetivos,
        )

        metodo = st.sidebar.selectbox(
            "Tratamiento del desbalance",
            METODOS,
            index=1,
        )

        corte = st.sidebar.slider(
            "Umbral de clasificación",
            min_value=0.05,
            max_value=0.95,
            value=0.50,
            step=0.05,
        )

        st.sidebar.caption(
            "El umbral determina desde qué puntuación "
            "se clasifica como Sí. Cambiarlo no modifica "
            "la probabilidad calculada."
        )

        resultado = clasificar(
            area,
            nombre,
            corte,
        )

    except (ValueError, OSError, KeyError) as error:
        error_area = str(error)

st.sidebar.divider()

st.sidebar.caption(
    "Actividad 3 · Despliegue de Regresión Logística"
)


# PESTAÑAS: SOLO SE DEFINEN UNA VEZ

inicio, general, especificas, escenarios, evaluacion = st.tabs([
    "Inicio",
    "Calculadora general",
    "Calculadoras específicas",
    "Escenarios A/B",
    "Evaluación y datos",
])


# INICIO

with inicio:
    st.subheader("Explora las herramientas de GAC")

    st.write(
        "Este dashboard reúne calculadoras para analizar "
        "la captación de leads y los resultados comerciales. "
        "Elige la herramienta según la pregunta "
        "que quieras responder."
    )

    izquierda, derecha = st.columns(2)

    with izquierda:
        with st.container(border=True):
            st.markdown("### 🧮 Calculadora general")

            st.write(
                "**¿Qué resultados podría tener "
                "un plan con varios canales?**"
            )

            st.write(
                "Selecciona canales e ingresa leads, "
                "citas y pruebas de manejo. Consulta "
                "las ventas estimadas por canal y "
                "el total del plan."
            )

        with st.container(border=True):
            st.markdown("### ⚖️ Escenarios A/B")

            st.write(
                "**¿Cómo cambia el resultado "
                "entre dos alternativas?**"
            )

            st.write(
                "Compara dos escenarios con el mismo "
                "modelo, método de balanceo y umbral."
            )

    with derecha:
        with st.container(border=True):
            st.markdown("### 🎯 Calculadoras específicas")

            st.write(
                "**¿Qué puedo analizar dentro de cada área?**"
            )

            st.write(
                "Abre las herramientas particulares "
                "de Marketing, Funnel, Leads, Plazas "
                "o Ranking."
            )

        with st.container(border=True):
            st.markdown("### 📊 Evaluación y datos")

            st.write(
                "**¿Cómo se desempeña el modelo?**"
            )

            st.write(
                "Revisa métricas, matriz de confusión, "
                "curva ROC, balanceo y preprocesamiento."
            )

    st.divider()

    st.markdown("### Guía de calculadoras específicas")

    guia = pd.DataFrame([
        {
            "Área": "Marketing",
            "Entradas": (
                "Plaza, modelo, color, duración "
                "y mes de inicio."
            ),
            "Resultado": (
                "Captación de al menos 4 leads por día. "
                "Calculadora adicional de ventas mensuales."
            ),
        },
        {
            "Área": "Funnel",
            "Entradas": (
                "Canal, leads, citas efectivas "
                "y pruebas de manejo."
            ),
            "Resultado": (
                "Clasificación de al menos 5 ventas "
                "y estimación de cantidad de ventas."
            ),
        },
        {
            "Área": "Leads",
            "Entradas": (
                "Leads mensuales, efectivos "
                "y categorías de calidad."
            ),
            "Resultado": (
                "Conversión mensual sobre efectivos "
                "de al menos 4%."
            ),
        },
        {
            "Área": "Plazas",
            "Entradas": (
                "Producto, origen, hora "
                "y día de la semana."
            ),
            "Resultado": (
                "Seguimiento, cita, prueba de manejo "
                "o solicitud de crédito."
            ),
        },
        {
            "Área": "Ranking",
            "Entradas": (
                "Ventas individuales "
                "y periodo de referencia."
            ),
            "Resultado": (
                "Posición comparativa y empates; "
                "no es un pronóstico."
            ),
        },
    ])

    st.dataframe(
        guia,
        hide_index=True,
        use_container_width=True,
    )

    st.info(
        "Comienza eligiendo una pestaña de arriba. "
        "Para las herramientas específicas, los escenarios "
        "y la evaluación, selecciona también el área "
        "en el menú izquierdo."
    )

    st.caption(
        "Los cortes de 4 leads por día, 5 ventas y "
        "4% de conversión son criterios analíticos "
        "del ejercicio, no metas oficiales de GAC."
    )


# CALCULADORA GENERAL

with general:
    st.subheader("Plan comercial por canal")

    st.write(
        "Construye un escenario mensual para comparar "
        "los resultados comerciales de distintos canales, "
        "como Digital, Piso o las plazas."
    )

    st.info(
        "Selecciona los canales que quieres incluir. "
        "Después, haz doble clic en las celdas de la tabla "
        "para modificar sus cantidades y presiona Enter. "
        "Los resultados se actualizan automáticamente."
    )

    with st.expander(
        "¿Qué debo ingresar y cómo se interpreta?"
    ):
        st.markdown("""
**Cada fila representa un canal durante un mismo mes.**
Usa ese mismo periodo para todas las cantidades.

- **Canal:** origen comercial que quieres analizar.
- **Leads generados:** prospectos registrados durante el mes.
- **Citas efectivas:** citas que sí se realizaron.
- **Pruebas de manejo:** pruebas realizadas durante el periodo.

**Valores iniciales:** medianas históricas por canal calculadas
con los datos de entrenamiento. Son un punto de partida editable,
no una meta recomendada.

**Al modificar las entradas:** el modelo actualiza las ventas
estimadas según las relaciones observadas en el histórico.
Aumentar una cantidad no garantiza un aumento proporcional
de ventas.

**Resultados:**

- **Leads del plan:** suma de los leads seleccionados.
- **Ventas estimadas del plan:** suma de las estimaciones
  numéricas por canal.
- **Relación ventas/leads estimada:** ventas estimadas divididas
  entre los leads del plan; no es una tasa real observada.
- **Puntuación ≥5 ventas:** salida de la logística para clasificar
  si cada canal-mes alcanza al menos cinco ventas.
  Estas puntuaciones no se suman.

Para explorar alternativas, cambia una cantidad a la vez.
Agregar o quitar canales también modifica el alcance del plan.
        """)

    st.caption(
        "Si ingresas cantidades futuras, planteas supuestos "
        "de actividad. La herramienta no predice por sí sola "
        "cuántas citas o pruebas conseguirás."
    )

    try:
        (
            modelo_ventas,
            datos_funnel,
            variables_funnel,
            entrenamiento_funnel,
            prueba_funnel,
            validacion_ventas,
        ) = regresion("Funnel")

        columnas_numericas = variables_funnel[1:]

        referencia = (
            datos_funnel.iloc[entrenamiento_funnel]
            .groupby("canal")[columnas_numericas]
            .median()
            .round()
            .reset_index()
        )

        canales = referencia["canal"].tolist()

        seleccionados = st.multiselect(
            "Canales del plan",
            canales,
            default=canales[:3],
        )

        plan_inicial = referencia[
            referencia["canal"].isin(seleccionados)
        ].reset_index(drop=True)

        plan = st.data_editor(
            plan_inicial,
            disabled=["canal"],
            hide_index=True,
            num_rows="fixed",
            use_container_width=True,
            key="editor_plan",
            column_config={
                "canal": st.column_config.TextColumn(
                    "Canal",
                ),
                "leads_generados": st.column_config.NumberColumn(
                    "Leads generados",
                    min_value=0,
                    step=1,
                ),
                "cita_efectiva": st.column_config.NumberColumn(
                    "Citas efectivas",
                    min_value=0,
                    step=1,
                ),
                "prueba_de_manejo": st.column_config.NumberColumn(
                    "Pruebas de manejo",
                    min_value=0,
                    step=1,
                ),
            },
        )

        valido = (
            not plan.empty
            and plan[columnas_numericas].notna().all().all()
            and (plan[columnas_numericas] >= 0).all().all()
        )

        if valido:
            if (
                (
                    plan["prueba_de_manejo"]
                    > plan["cita_efectiva"]
                ).any()
                or (
                    plan["cita_efectiva"]
                    > plan["leads_generados"]
                ).any()
            ):
                st.warning(
                    "Hay etapas que superan a la anterior. "
                    "Revisa las cantidades y las definiciones "
                    "de tus indicadores."
                )

            ventas_estimadas = np.maximum(
                0,
                modelo_ventas.predict(
                    plan[variables_funnel]
                ),
            )

            sin_leads = (
                plan["leads_generados"].to_numpy() == 0
            )

            ventas_estimadas = np.where(
                sin_leads,
                0,
                ventas_estimadas,
            )

            resultado_funnel = clasificar(
                "Funnel",
                "Canal-mes con ≥ 5 ventas",
                0.5,
            )

            puntuaciones = (
                resultado_funnel["modelos"]["Sin ajuste"]
                .predict_proba(
                    plan[variables_funnel]
                )[:, 1]
            )

            salida = plan.copy()

            salida["Ventas estimadas"] = (
                ventas_estimadas.round(2)
            )

            salida["Puntuación ≥5 ventas"] = (
                puntuaciones
            )

            total_leads = float(
                plan["leads_generados"].sum()
            )

            total_ventas = float(
                ventas_estimadas.sum()
            )

            relacion = (
                total_ventas / total_leads
                if total_leads > 0
                else 0
            )

            a, b, c = st.columns(3)

            a.metric(
                "Leads del plan",
                f"{total_leads:,.0f}",
            )

            b.metric(
                "Ventas estimadas del plan",
                f"{total_ventas:.1f}",
            )

            c.metric(
                "Relación ventas/leads estimada",
                f"{relacion:.1%}",
            )

            st.dataframe(
                salida.round(3),
                hide_index=True,
                use_container_width=True,
            )

            grafica(
                px.bar(
                    salida,
                    x="canal",
                    y="Ventas estimadas",
                    title="Ventas estimadas por canal",
                    color_discrete_sequence=["#E32636"],
                )
            )

            st.download_button(
                "Descargar plan",
                convertir_csv(salida),
                "plan_comercial.csv",
                "text/csv",
            )

            for columna in columnas_numericas:
                fuera = (
                    (
                        plan[columna]
                        < datos_funnel[columna].min()
                    )
                    | (
                        plan[columna]
                        > datos_funnel[columna].max()
                    )
                )

                if fuera.any():
                    st.warning(
                        f"{columna}: hay cantidades "
                        "fuera del rango histórico."
                    )

            st.caption(
                "La cantidad de ventas se estima con "
                "regresión Ridge, como complemento de la "
                "logística. Las estimaciones negativas "
                "se limitan a cero; sin leads se muestra "
                "cero por regla operativa. Los modelos "
                "no se reentrenan con los datos de prueba."
            )

        else:
            st.info(
                "Selecciona al menos un canal e ingresa "
                "cantidades no negativas, sin celdas vacías."
            )

        with st.expander(
            "Validación de la estimación numérica"
        ):
            st.dataframe(
                validacion_ventas.round(3),
                hide_index=True,
            )

            st.caption(
                "MAE y RMSE se calculan sobre meses de "
                "prueba completos. Un valor menor indica "
                "menor error. Se compara contra la media "
                "del entrenamiento. El error del total "
                "del plan no se obtiene sumando MAE."
            )

    except (ValueError, OSError, KeyError) as error:
        st.error(str(error))


# CALCULADORAS ESPECÍFICAS

with especificas:
    if area == "Ranking":
        st.subheader("Ranking por ventas")

        st.write(
            "Compara las ventas de un vendedor con "
            "el histórico del periodo seleccionado. "
            "Los empates comparten posición."
        )

        ventas = st.number_input(
            "Ventas individuales a comparar",
            min_value=0,
            value=30,
            step=1,
        )

        periodo = st.selectbox(
            "Periodo de referencia",
            [
                "Acum",
                "Acum 2024",
                "Acum 2025",
                "Acum 2026",
            ],
            key="periodo_ranking",
        )

        try:
            posicion, empates, numero = ranking(
                ventas,
                periodo,
            )

            a, b, c = st.columns(3)

            a.metric(
                "Posición comparativa",
                f"#{posicion}",
            )

            b.metric(
                "Empates",
                empates,
            )

            c.metric(
                "Registros históricos",
                numero,
            )

            st.caption(
                "Es una comparación, no un pronóstico. "
                "Asegúrate de comparar cantidades "
                "correspondientes a periodos equivalentes."
            )

        except (ValueError, OSError, KeyError) as error:
            st.error(str(error))

    elif resultado is None:
        st.error(error_area or "No se pudo cargar el modelo.")

    else:
        st.subheader(f"{area} | {nombre}")

        st.write(DESCRIPCIONES[area])

        st.caption(
            "Modifica las entradas para actualizar el "
            "resultado. El método y el umbral se eligen "
            "en el menú izquierdo."
        )

        entrada = formulario(
            resultado["d"][variables],
            f"especifica_{area}_{nombre}",
        )

        mostrar_probabilidad(
            resultado,
            entrada,
            metodo,
            corte,
        )

        aviso_probabilidad()

        if area == "Marketing":
            with st.expander(
                "Calculadora adicional de ventas mensuales"
            ):
                st.write(
                    "Ingresa los leads mensuales de Plaza, "
                    "Digital y Piso para estimar las ventas "
                    "totales del mes."
                )

                st.caption(
                    "Esta herramienta usa 29 meses, "
                    "separados de las 87 exhibiciones. "
                    "Modelo lineal con regularización Ridge."
                )

                (
                    modelo_mensual,
                    datos_mensuales,
                    variables_mensuales,
                    _,
                    _,
                    validacion_mensual,
                ) = regresion("Marketing mensual")

                entrada_mensual = formulario(
                    datos_mensuales[variables_mensuales],
                    "marketing_mensual",
                )

                venta_mensual = max(
                    0,
                    float(
                        modelo_mensual.predict(
                            entrada_mensual
                        )[0]
                    ),
                )

                st.metric(
                    "Ventas mensuales estimadas",
                    f"{venta_mensual:.1f}",
                )

                st.dataframe(
                    validacion_mensual.round(3),
                    hide_index=True,
                )

                st.caption(
                    "Evaluación en los últimos seis meses. "
                    "Resultado exploratorio por el "
                    "historial limitado."
                )

        elif area == "Leads":
            conversion = (
                100
                * datos["Ventas"].sum()
                / datos["Efectivos"].sum()
            )

            st.metric(
                "Conversión ponderada del histórico",
                f"{conversion:.2f}%",
            )

            st.caption(
                "Ventas totales/efectivos totales. "
                "Es una referencia descriptiva."
            )

        elif area == "Funnel":
            modelo_funnel, *_ = regresion("Funnel")

            cantidad = max(
                0,
                float(
                    modelo_funnel.predict(entrada)[0]
                ),
            )

            st.metric(
                "Ventas estimadas del canal-mes",
                f"{cantidad:.1f}",
            )

            st.caption(
                "Estimación numérica adicional a la "
                "clasificación. Consulta su validación "
                "en Calculadora general."
            )


# ESCENARIOS A/B

with escenarios:
    if area == "Ranking":
        st.subheader("Escenarios de ranking")

        periodo_ab = st.selectbox(
            "Periodo para ambos escenarios",
            [
                "Acum",
                "Acum 2024",
                "Acum 2025",
                "Acum 2026",
            ],
            key="periodo_ranking_ab",
        )

        a, b = st.columns(2)

        with a:
            ventas_a = st.number_input(
                "Ventas individuales A",
                min_value=0,
                value=20,
                step=1,
            )

        with b:
            ventas_b = st.number_input(
                "Ventas individuales B",
                min_value=0,
                value=30,
                step=1,
            )

        try:
            posicion_a = ranking(
                ventas_a,
                periodo_ab,
            )[0]

            posicion_b = ranking(
                ventas_b,
                periodo_ab,
            )[0]

            a.metric(
                "Posición A",
                f"#{posicion_a}",
            )

            b.metric(
                "Posición B",
                f"#{posicion_b}",
            )

        except (ValueError, OSError, KeyError) as error:
            st.error(str(error))

    elif resultado is None:
        st.error(error_area or "No se pudo cargar el modelo.")

    else:
        st.subheader(f"Escenarios A/B | {area}")

        st.write(
            "Construye dos alternativas y compara "
            "la puntuación de cada una. Para explorar "
            "una diferencia concreta, modifica una "
            "característica a la vez."
        )

        st.caption(
            f"Objetivo: {nombre} · Método: {metodo} · "
            f"Umbral: {corte:.2f}"
        )

        entradas = []
        probabilidades = []

        for etiqueta, columna in zip(
            ["A", "B"],
            st.columns(2),
        ):
            with columna:
                st.markdown(
                    f"### Escenario {etiqueta}"
                )

                entrada_ab = formulario(
                    resultado["d"][variables],
                    f"ab_{area}_{nombre}_{etiqueta}",
                )

                entradas.append(entrada_ab)

                probabilidad = mostrar_probabilidad(
                    resultado,
                    entrada_ab,
                    metodo,
                    corte,
                )

                probabilidades.append(probabilidad)

        if None not in probabilidades:
            diferencia = 100 * (
                probabilidades[1]
                - probabilidades[0]
            )

            st.metric(
                "Cambio B − A",
                f"{diferencia:+.1f} puntos porcentuales",
            )

            salida_ab = pd.concat(
                entradas,
                ignore_index=True,
            )

            salida_ab["Escenario"] = ["A", "B"]
            salida_ab["Probabilidad"] = probabilidades

            st.download_button(
                "Descargar escenarios",
                convertir_csv(salida_ab),
                f"escenarios_{area}.csv",
                "text/csv",
            )

        aviso_probabilidad()


# EVALUACIÓN Y DATOS

with evaluacion:
    if area == "Ranking":
        st.info(
            "Ranking realiza una comparación histórica, "
            "no una clasificación logística. Por eso "
            "no tiene matriz de confusión ni curva ROC."
        )

    elif resultado is None:
        st.error(error_area or "No se pudo cargar el modelo.")

    else:
        st.subheader(f"Evaluación | {area}")

        y_prueba = resultado["y"].iloc[
            resultado["te"]
        ]

        fila = (
            resultado["tabla"]
            .set_index("Método")
            .loc[metodo]
        )

        st.caption(
            f"Observaciones: {len(resultado['d'])} · "
            f"Entrenamiento: {len(resultado['tr'])} · "
            f"Prueba: {len(y_prueba)} · "
            f"Positivos en prueba: {int(y_prueba.sum())} · "
            "Semilla: 42."
        )

        with st.expander("Cómo leer las métricas"):
            st.markdown("""
- **Exactitud:** proporción de predicciones correctas.
- **Precisión:** de los casos clasificados como Sí,
  cuántos realmente fueron positivos.
- **Sensibilidad:** de todos los positivos reales,
  cuántos detectó el modelo.
- **F1:** combina precisión y sensibilidad.
- **AUC:** capacidad de distinguir las clases a lo largo
  de distintos umbrales. Un valor cercano a 0.5 indica
  poca discriminación.
            """)

        for columna, metrica in zip(
            st.columns(5),
            [
                "Exactitud",
                "Precisión",
                "Sensibilidad",
                "F1",
                "AUC",
            ],
        ):
            valor = fila[metrica]

            columna.metric(
                metrica,
                (
                    f"{valor:.3f}"
                    if pd.notna(valor)
                    else "No disponible"
                ),
            )

        izquierda, derecha = st.columns(2)

        with izquierda:
            matriz = pd.DataFrame(
                [
                    [fila["VN"], fila["FP"]],
                    [fila["FN"], fila["VP"]],
                ],
                index=[
                    "Real No",
                    "Real Sí",
                ],
                columns=[
                    "Predicho No",
                    "Predicho Sí",
                ],
            ).astype(int)

            grafica(
                px.imshow(
                    matriz,
                    text_auto=True,
                    color_continuous_scale="Reds",
                    title="Matriz de confusión · Prueba",
                )
            )

        with derecha:
            if y_prueba.nunique() == 2:
                fpr, tpr, _ = roc_curve(
                    y_prueba,
                    resultado["probs"][metodo],
                )

                figura_roc = go.Figure()

                figura_roc.add_trace(
                    go.Scatter(
                        x=fpr,
                        y=tpr,
                        name="Modelo",
                        line=dict(
                            color="#E32636",
                            width=3,
                        ),
                    )
                )

                figura_roc.add_trace(
                    go.Scatter(
                        x=[0, 1],
                        y=[0, 1],
                        name="Azar",
                        line=dict(
                            dash="dash",
                            color="gray",
                        ),
                    )
                )

                figura_roc.update_layout(
                    title="Curva ROC · Prueba",
                    xaxis_title="Tasa de falsos positivos",
                    yaxis_title="Sensibilidad",
                )

                grafica(figura_roc)

            else:
                st.info(
                    "ROC y AUC requieren ambas clases "
                    "en el conjunto de prueba."
                )

        st.markdown("### Comparación de balanceo")

        st.dataframe(
            resultado["tabla"].round(3),
            hide_index=True,
            use_container_width=True,
        )

        mayoritaria = int(
            resultado["y"].iloc[
                resultado["tr"]
            ].mode().iloc[0]
        )

        exactitud_referencia = (
            y_prueba == mayoritaria
        ).mean()

        st.caption(
            "Exactitud al predecir siempre la clase "
            "mayoritaria del entrenamiento: "
            f"{exactitud_referencia:.1%}. "
            "VP/VN: verdaderos positivos/negativos. "
            "FP/FN: falsos positivos/negativos."
        )

        st.download_button(
            "Descargar métricas",
            convertir_csv(resultado["tabla"]),
            f"metricas_{area}.csv",
            "text/csv",
        )

        st.warning(
            "Marketing y Funnel mantienen juntas las filas "
            "del mismo mes de inicio o periodo. Esto no "
            "equivale a una validación temporal futura. "
            "Leads tiene pocos meses y SDC pocos positivos. "
            "Explorar umbrales mirando el test no sustituye "
            "una validación independiente."
        )

        with st.expander(
            "Base analítica y preprocesamiento"
        ):
            st.write(resultado["nota"])

            st.write(
                f"Filas revisadas: {resultado['original']} · "
                "Utilizables para este objetivo: "
                f"{len(resultado['d'])}."
            )

            st.markdown("""
**Nulos:** se excluyen objetivos ausentes. Los predictores
numéricos se imputan con la mediana del entrenamiento
y los categóricos con una categoría explícita.

**Atípicos:** límites IQR aprendidos únicamente del
entrenamiento. No se eliminan observaciones de prueba.

**Transformaciones:** estandarización numérica y codificación
de categorías con indicadores binarios.

**Desbalance:** reponderación u oversampling únicamente
en entrenamiento. El conjunto de prueba no se balancea.
            """)

            tabla_base = resultado["d"][
                variables
            ].copy()

            tabla_base["Objetivo"] = resultado["y"]

            st.dataframe(
                tabla_base,
                hide_index=True,
                use_container_width=True,
            )

            st.download_button(
                "Descargar base analítica",
                convertir_csv(tabla_base),
                f"base_{area}.csv",
                "text/csv",
            )

        with st.expander(
            "Coeficientes del modelo"
        ):
            modelo = resultado["modelos"][metodo]

            coeficientes = pd.DataFrame({
                "Variable": (
                    modelo["pre"].get_feature_names_out()
                ),
                "Coeficiente": (
                    modelo["modelo"].coef_[0]
                ),
            })

            coeficientes["Odds ratio"] = np.exp(
                coeficientes["Coeficiente"]
            )

            st.dataframe(
                coeficientes.round(4),
                hide_index=True,
                use_container_width=True,
            )

            st.caption(
                "Los coeficientes muestran asociaciones, "
                "no efectos causales. Para variables "
                "numéricas, corresponden a una desviación "
                "estándar después del tratamiento de "
                "atípicos. Los odds ratios no representan "
                "cambios directos en puntos porcentuales."
            )